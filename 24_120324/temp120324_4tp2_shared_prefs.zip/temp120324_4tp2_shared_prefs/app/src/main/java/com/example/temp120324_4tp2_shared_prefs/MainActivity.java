package com.example.temp120324_4tp2_shared_prefs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.chip.Chip;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public static final String SHARED_1 = "shared_prefs";
    public static final String NUM_KEY = "random_number";
    private Button btnRandom;
    private Chip chip;
    private Random random = new Random();
    private int randomNum;
    private SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnRandom = findViewById(R.id.btnRandom);
        chip = findViewById(R.id.chip);
        sharedPreferences = getSharedPreferences(SHARED_1, MODE_PRIVATE);

        loadPrefs();

        if(randomNum > 0) {
            chip.setText(String.valueOf(randomNum));
            chip.setVisibility(View.VISIBLE);
        }

        chip.setOnCloseIconClickListener(view -> {
            sharedPreferences.edit().clear().apply();
            chip.setVisibility(View.INVISIBLE);
            Toast.makeText(this, "Pamięć wyczyszczona", Toast.LENGTH_SHORT).show();
        });



        btnRandom.setOnClickListener(view -> {
            randomNum = random.nextInt(100) + 1;
            chip.setText(String.valueOf(randomNum));
            chip.setVisibility(View.VISIBLE);
            savePrefs();
        });
    }

    private void savePrefs() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(NUM_KEY, randomNum);
        editor.apply();
    }

    private void loadPrefs() {
        randomNum = sharedPreferences.getInt(NUM_KEY, 0);
    }
}