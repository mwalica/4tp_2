package com.example.temp130224_jsonobj_4tp2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    public static final String json = "{\n" +
            "  \"firstName\": \"Adam\",\n" +
            "  \"age\": 23\n" +
            "}";

    private Button btnShow;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnShow = findViewById(R.id.btnShow);
        tvResult = findViewById(R.id.tvResult);

        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    JSONObject person = new JSONObject(loadJsonFromAssets());
                    String firstName = person.getString("firstName");
                    int age = person.getInt("age");
                    JSONObject address = person.getJSONObject("address");
                    String country = address.getString("country");
                    String city = address.getString("city");

                    JSONArray hobbies = person.getJSONArray("hobbies");
                    String str = "";
                    for(int i = 0; i < hobbies.length(); i++) {
                        str += hobbies.get(i) + " ";
                    }

                    tvResult.setText(firstName + " ma lat " + age + "\n " + country + ", " + city + "\n" + str);
                } catch(JSONException error) {
                    Toast.makeText(MainActivity.this, "Błąd: " + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private String loadJsonFromAssets() {
        String json = null;
        try {
            InputStream inputStream = getAssets().open("person.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();

            json = new String(buffer, "UTF-8");
        } catch(IOException error) {
            Toast.makeText(this, "Error: " + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            return "";
        }

        return json;
    }
}