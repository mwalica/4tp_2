package com.example.temp100324_4tp2_seekbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private SeekBar seekBar;
    private TextView tvResult1, tvResult2;
    private int p = 0;
    private int start;
    private int stop;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekBar = findViewById(R.id.seekBar);
        tvResult1 = findViewById(R.id.tvResult1);
        tvResult2 = findViewById(R.id.tvResult2);

        seekBar.setMin(-10);
        seekBar.setMax(10);
        seekBar.setProgress(p);
        tvResult1.setText(String.valueOf(p));

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
//                p = progress;
                p = seekBar.getProgress();
                tvResult1.setText(String.valueOf(p));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                start = seekBar.getProgress();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                stop = seekBar.getProgress();
                tvResult2.setText(String.valueOf(stop - start));
            }
        });
    }
}