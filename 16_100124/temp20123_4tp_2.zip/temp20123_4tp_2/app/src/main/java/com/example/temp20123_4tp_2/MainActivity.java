package com.example.temp20123_4tp_2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.temp20123_4tp_2.adapter.NotesAdapter;
import com.example.temp20123_4tp_2.database.DatabaseHelper;
import com.example.temp20123_4tp_2.model.Note;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FloatingActionButton floatingActionButton;
    private TextView tvInfo;
    private List<Note> notes = new ArrayList<>();
    private DatabaseHelper databaseHelper;
    private NotesAdapter notesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        floatingActionButton = findViewById(R.id.floatingActionButton);
        tvInfo = findViewById(R.id.tvInfo);
        databaseHelper = new DatabaseHelper(MainActivity.this);


        storeNoteInList();

        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        notesAdapter = new NotesAdapter(notes, (position, view) -> {
            if(view.getId() == R.id.ivDelete) {
                databaseHelper.deleteNote(notes.get(position).getId());
                notes.remove(position);
                notesAdapter.notifyItemRemoved(position);
                notesAdapter.notifyItemRangeChanged(position, 1);
            } else {
                Intent intent = new Intent(MainActivity.this, EditActivity.class);
                intent.putExtra("note_obj", notes.get(position));
                startActivity(intent);
            }

        });
        recyclerView.setAdapter(notesAdapter);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });
    }

    private void storeNoteInList() {
        Cursor cursor = databaseHelper.getAllNotes();
        if(cursor.getCount() == 0) {
            tvInfo.setVisibility(View.VISIBLE);
        } else {
            tvInfo.setVisibility(View.GONE);
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                String description = cursor.getString(2);
                long createdDate = cursor.getLong(3);
                notes.add(new Note(id, title, description, createdDate));
            }
            Log.d("my_log", "storeNoteInList: " + notes.size());
        }
    }
}