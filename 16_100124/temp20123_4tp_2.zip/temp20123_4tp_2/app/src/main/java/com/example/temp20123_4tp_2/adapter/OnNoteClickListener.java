package com.example.temp20123_4tp_2.adapter;

import android.view.View;

public interface OnNoteClickListener {
    void onNoteClick(int position, View view);
}
