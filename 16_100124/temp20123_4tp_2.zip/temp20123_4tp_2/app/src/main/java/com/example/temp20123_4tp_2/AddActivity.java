package com.example.temp20123_4tp_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.temp20123_4tp_2.database.DatabaseHelper;
import com.example.temp20123_4tp_2.model.Note;

public class AddActivity extends AppCompatActivity {

    private EditText etTitle, etDescription;
    private Button btnSend;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        etTitle = findViewById(R.id.etTitle);
        etDescription = findViewById(R.id.etDescription);
        btnSend = findViewById(R.id.btnSend);

        databaseHelper = new DatabaseHelper(AddActivity.this);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = etTitle.getText().toString().trim();
                String description = etDescription.getText().toString().trim();
                if(!title.isEmpty() && !description.isEmpty()) {
                databaseHelper.addNote(new Note(title, description));
                etTitle.getText().clear();
                etDescription.getText().clear();
                } else {
                    Toast.makeText(AddActivity.this, "Proszę wypełnić formularz", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}