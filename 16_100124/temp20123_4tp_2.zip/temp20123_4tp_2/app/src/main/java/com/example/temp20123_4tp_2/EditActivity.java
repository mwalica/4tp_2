package com.example.temp20123_4tp_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.example.temp20123_4tp_2.database.DatabaseHelper;
import com.example.temp20123_4tp_2.model.Note;

import java.io.Serializable;

public class EditActivity extends AppCompatActivity {
    private EditText etEditTitle, etEditDescription;
    private Button btnEdit;
    private String title, description;
    private int id;
    private long createdDate;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        etEditTitle = findViewById(R.id.etEditTitle);
        etEditDescription = findViewById(R.id.etEditDescription);
        btnEdit = findViewById(R.id.btnEdit);

        databaseHelper = new DatabaseHelper(EditActivity.this);

        if(getIntent().hasExtra("note_obj")) {
            Note note = (Note) getIntent().getSerializableExtra("note_obj");
            title = note.getTitle();
            description = note.getDescription();
            id = note.getId();
            createdDate = note.getCreatedDate();
            etEditTitle.setText(title);
            etEditDescription.setText(description);

        }

        btnEdit.setOnClickListener(view -> {
            title = etEditTitle.getText().toString().trim();
            description = etEditDescription.getText().toString().trim();
            if(!title.isEmpty() && !description.isEmpty()) {
                databaseHelper.editNote(new Note(id, title, description, createdDate));
            }
        });
    }
}