package com.example.temp190923_4tp_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    private TextView tvResult;
    private Button btnToMainScreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        tvResult = findViewById(R.id.tvResult);
        btnToMainScreen = findViewById(R.id.btnToMainScreen);

        if(getIntent().hasExtra(MainActivity.NAME_KEY)) {
            String name = getIntent().getStringExtra(MainActivity.NAME_KEY);
            int age = getIntent().getIntExtra(MainActivity.AGE_KEY, 0);
            tvResult.setText(name + ", " + age + " " + getResources().getString(R.string.years_old));
        }

        btnToMainScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}