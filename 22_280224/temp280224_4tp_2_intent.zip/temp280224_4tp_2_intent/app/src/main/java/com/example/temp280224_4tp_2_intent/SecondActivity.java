package com.example.temp280224_4tp_2_intent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.temp280224_4tp_2_intent.model.Person;

public class SecondActivity extends AppCompatActivity {

    private Button btnBack;
    private TextView tvResult;
    private String name = "";
    private int age = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        btnBack = findViewById(R.id.btnBack);
        tvResult = findViewById(R.id.tvResult);

        if(getIntent().hasExtra(MainActivity.PERSON_KEY)) {
            Person person = (Person) getIntent().getSerializableExtra(MainActivity.PERSON_KEY);
            name = person.getName();
            age = person.getAge();
            tvResult.setText("Witaj " + name + " " + age);
        }

        btnBack.setOnClickListener(view -> {
            finish();
        });

    }
}