package com.example.temp280224_4tp_2_intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.example.temp280224_4tp_2_intent.model.Person;

public class MainActivity extends AppCompatActivity {

    public static final String NAME_KEY = "name";
    public static final String PERSON_KEY = "person_obj";
    private Button btnToSecond, btnSendText, btnEmail, btnWeb, btnDial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnToSecond = findViewById(R.id.btnToSecond);
        btnSendText = findViewById(R.id.btnSendText);
        btnEmail = findViewById(R.id.btnEmail);
        btnWeb = findViewById(R.id.btnWeb);
        btnDial = findViewById(R.id.btnDial);

        btnToSecond.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
//            intent.putExtra(NAME_KEY, "Karol");
            intent.putExtra(PERSON_KEY, new Person("Adam"));
            startActivity(intent);
        });

        btnSendText.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, "To jest tekst wysyłany");
            try {
                startActivity(Intent.createChooser(intent, "Wybierz aplikację..."));
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "Błąd: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }

        });

        btnEmail.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:"));
            intent.putExtra(Intent.EXTRA_SUBJECT, "Tytuł wiadomości e-mail");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"mwalica@wp.pl", "marek.walica@szybinski.cieszyn.pl"});
            intent.putExtra(Intent.EXTRA_TEXT, "Treśc wiadomości");
            try {
                startActivity(intent);
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "Błąd: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }

        });

        btnWeb.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://www.onet.pl"));
            try {
                startActivity(intent);
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "Błąd: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        btnDial.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:600200100"));
            try {
                startActivity(intent);
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "Błąd: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}