package com.example.temp280224_4tp_2_intent.model;

import java.io.Serializable;
import java.util.Random;

public class Person implements Serializable {
    private String name;
    private int age;

    public Person(String name) {
        this.name = name;
        this.age = new Random().nextInt(90) + 1;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
