package com.example.temp171023_4tp_2;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ConstraintLayout constraintLayout;
    private TextView tvColor1, tvColor2;
    private Button btnToSpinner;
    private ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        constraintLayout = findViewById(R.id.constrainLayout);
        tvColor1 = findViewById(R.id.tvColor1);
        tvColor2 = findViewById(R.id.tvColor2);
        btnToSpinner = findViewById(R.id.btnToSpinner);

        tvColor1.setOnClickListener(this);
        tvColor2.setOnClickListener(this);

        btnToSpinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, SpinnerActivity.class));
            }
        });

    }


    @Override
    public void onClick(View view) {
        ColorDrawable background = (ColorDrawable) view.getBackground();
        int color = background.getColor();
        constraintLayout.setBackgroundColor(color);
    }
}