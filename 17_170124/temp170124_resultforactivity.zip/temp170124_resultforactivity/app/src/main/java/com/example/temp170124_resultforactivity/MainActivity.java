package com.example.temp170124_resultforactivity;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String TO_SECOND = "number";
    private Button btnToSecond;
    private ActivityResultLauncher<Integer> launcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnToSecond = findViewById(R.id.btnToSecond);
        launcher = registerForActivityResult(new ActivityResultContract<Integer, Double>() {

            @Override
            public Double parseResult(int resultCode, @Nullable Intent intent) {
                if(resultCode == RESULT_OK) {
                    return intent.getDoubleExtra(SecondActivity.TO_MAIN, 0.0);
                }
                return 10.0;
            }

            @NonNull
            @Override
            public Intent createIntent(@NonNull Context context, Integer integer) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                return intent.putExtra(TO_SECOND, integer);

            }
        }, result -> {
            Toast.makeText(this, "Wynik: " + result, Toast.LENGTH_SHORT).show();
        });

        btnToSecond.setOnClickListener(view -> {
            launcher.launch(201);
        });
    }
}