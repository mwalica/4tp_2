package com.example.temp170124_resultforactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    public static final String TO_MAIN = "double";
    private TextView tvResult;
    private Button btnToMain;
    private int num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tvResult = findViewById(R.id.tvResult);
        btnToMain = findViewById(R.id.btnToMain);

        if(getIntent().hasExtra(MainActivity.TO_SECOND)) {
            num = getIntent().getIntExtra(MainActivity.TO_SECOND, 0);
        }

        tvResult.setText(num + "");

        btnToMain.setOnClickListener(view -> {
            Intent intent = new Intent().putExtra(SecondActivity.TO_MAIN, num * 1.5);
            setResult(RESULT_OK, intent);
            finish();
        });
    }
}