package com.example.temp61223_4tp_2_rv.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.temp61223_4tp_2_rv.R;
import com.example.temp61223_4tp_2_rv.model.Person;

public class PersonViewHolder extends RecyclerView.ViewHolder {

    private TextView tvName, tvAge;
    private ImageView ivPhoto;
    public PersonViewHolder(View itemView) {
        super(itemView);
        tvName = itemView.findViewById(R.id.tvName);
        tvAge = itemView.findViewById(R.id.tvAge);
        ivPhoto = itemView.findViewById(R.id.ivPhoto);
    }

    public void bind(Person person) {
        tvName.setText(person.getName());
        tvAge.setText(person.getAge() + " lat");
        ivPhoto.setImageResource(R.drawable.temp);
    }
}
