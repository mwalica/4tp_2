package com.example.temp61223_4tp_2_rv.model;

public class Person {
    private String name;
    private int age;
    //private String imageUrl;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
