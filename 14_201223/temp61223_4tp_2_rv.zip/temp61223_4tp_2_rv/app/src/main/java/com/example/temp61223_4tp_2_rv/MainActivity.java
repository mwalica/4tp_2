package com.example.temp61223_4tp_2_rv;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.temp61223_4tp_2_rv.adapter.PersonsAdapter;
import com.example.temp61223_4tp_2_rv.model.Person;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Person> persons = new ArrayList<>();
    private PersonsAdapter personsAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        persons.add(new Person("Jan", 45));
        persons.add(new Person("Adam", 23));
        persons.add(new Person("Konrad", 19));
        persons.add(new Person("Gustaw", 47));
        persons.add(new Person("Marcin", 32));

        //tworze adapter
        personsAdapter = new PersonsAdapter(persons);

        //ustawiam układ wyświetlanej listy
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        recyclerView.setAdapter(personsAdapter);



    }
}