package com.example.temp20123_4tp_2.model;

import java.time.Instant;

public class Note {
    private int id;
    private String title;
    private String description;
    private long createdDate;

    public Note(String title, String description) {
        this.id = -1;
        this.title = title;
        this.description = description;
        this.createdDate = Instant.now().getEpochSecond();
    }
}
