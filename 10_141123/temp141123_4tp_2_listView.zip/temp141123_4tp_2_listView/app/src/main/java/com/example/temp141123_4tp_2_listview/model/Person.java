package com.example.temp141123_4tp_2_listview.model;

import androidx.annotation.NonNull;

public class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @NonNull
    @Override
    public String toString() {
        return name + ", lat: " + age;
    }
}
