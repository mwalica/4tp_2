package com.example.temp141123_4tp_2_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.temp141123_4tp_2_listview.model.Person;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private String[] names = {"Jan", "Adam", "Karolina", "Dominika", "Jan", "Adam", "Karolina", "Dominika", "Jan", "Adam", "Karolina", "Dominika", };
    private List<Person> persons = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        persons.add(new Person("Agata", 34));
        persons.add(new Person("Ania", 32));
        persons.add(new Person("Alicja", 35));
        persons.add(new Person("Adam", 23));
        persons.add(new Person("Andrzej", 38));


//        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, R.layout.list_item, names);
        ArrayAdapter<Person> adapter2 = new ArrayAdapter<>(this, R.layout.list_item, persons);
        listView.setAdapter(adapter2);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Toast.makeText(MainActivity.this, "Klknięto: " + persons.get(position).getName() + " " + persons.get(position).getAge(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}