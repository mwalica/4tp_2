package com.example.temp210224_4tp_2_retrofit;

import com.example.temp210224_4tp_2_retrofit.model.Post;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {

    @GET("posts")
    Call<List<Post>> getPosts();
}
