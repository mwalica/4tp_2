package com.example.temp210224_4tp_2_retrofit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.temp210224_4tp_2_retrofit.model.Post;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ProgressBar progressBar;
    private List<Post> posts = new ArrayList<>();
    private ApiInterface apiInterface;
    ArrayAdapter<Post> adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        progressBar = findViewById(R.id.progressBar);

        fetchPosts();

        adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, posts);
        listView.setAdapter(adapter);

    }

    private void fetchPosts() {
        progressBar.setVisibility(View.VISIBLE);
        Retrofit retrofit = ApiClient.getRetrofit();
        apiInterface = retrofit.create(ApiInterface.class);

        Call<List<Post>> call = apiInterface.getPosts();
        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                if(!response.isSuccessful()) {
                    Toast.makeText(MainActivity.this, "Kod błedu: " + response.code(), Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                    return;
                }

                assert response.body() != null;
                posts.addAll(response.body());
                progressBar.setVisibility(View.GONE);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable e) {
                Toast.makeText(MainActivity.this, "Błąd: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
            }
        });
    }
}