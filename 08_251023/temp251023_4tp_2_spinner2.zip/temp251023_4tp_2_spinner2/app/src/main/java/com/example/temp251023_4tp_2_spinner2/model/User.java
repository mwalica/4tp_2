package com.example.temp251023_4tp_2_spinner2.model;

import androidx.annotation.NonNull;

public class User {
    private String name;
    private int age;

    public User(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @NonNull
    @Override
    public String toString() {
        return name.toUpperCase();
    }
}
