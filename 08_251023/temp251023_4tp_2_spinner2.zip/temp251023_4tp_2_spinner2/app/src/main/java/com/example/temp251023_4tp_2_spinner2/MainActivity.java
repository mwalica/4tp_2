package com.example.temp251023_4tp_2_spinner2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.temp251023_4tp_2_spinner2.model.User;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private String[] names = {"Jan", "Karol", "Gustaw"};
    private List<User> users = new ArrayList<>();
    String selectedItem = "Jan";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);

        users.add(new User("Anna", 34));
        users.add(new User("Dominika", 24));
        users.add(new User("Iza", 54));

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, names);
        ArrayAdapter<User> adapter2 = new ArrayAdapter<>(MainActivity.this, R.layout.spinner_item, users);

        spinner.setAdapter(adapter2);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                selectedItem = users.get(position).getName() + ", " + users.get(position).getAge();
//                selectedItem = (String) adapterView.getSelectedItem();
                Toast.makeText(MainActivity.this, selectedItem, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }
}