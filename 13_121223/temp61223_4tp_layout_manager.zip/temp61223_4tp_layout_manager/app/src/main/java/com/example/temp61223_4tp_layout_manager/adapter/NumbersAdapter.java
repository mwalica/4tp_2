package com.example.temp61223_4tp_layout_manager.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.temp61223_4tp_layout_manager.R;

public class NumbersAdapter extends RecyclerView.Adapter<NumbersAdapter.NumViewHolder> {

    private int[] numbers;

    public NumbersAdapter(int[] numbers) {
        this.numbers = numbers;
    }

    @NonNull
    @Override
    public NumViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.number_item, parent, false);
        return new NumViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NumViewHolder holder, int position) {
        holder.bind(numbers[position]);
    }

    @Override
    public int getItemCount() {
        return numbers.length;
    }

    //class ViewHolder
    class NumViewHolder extends RecyclerView.ViewHolder {

        TextView tvNum;

        public NumViewHolder(View itemView) {
            super(itemView);
            tvNum = itemView.findViewById(R.id.tvNum);
        }

        public void bind(int num) {
            tvNum.setText(String.valueOf(num));
        }
    }
}
