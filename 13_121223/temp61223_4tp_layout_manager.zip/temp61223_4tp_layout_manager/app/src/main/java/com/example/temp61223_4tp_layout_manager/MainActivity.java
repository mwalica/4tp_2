package com.example.temp61223_4tp_layout_manager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.temp61223_4tp_layout_manager.adapter.NumbersAdapter;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private int[] numbers = {2, 5, 6, 7, 90, 23, 98, 25, 98, 12, 90, 45};
    private NumbersAdapter numbersAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        numbersAdapter = new NumbersAdapter(numbers);

//        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false));
        recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
        recyclerView.setAdapter(numbersAdapter);

    }
}