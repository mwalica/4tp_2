package com.example.temp130224_jsonobj_4tp2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Outline;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.temp130224_jsonobj_4tp2.model.Person;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Person> persons = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        recyclerView = findViewById(R.id.recyclerView);

        try {
            JSONArray personsJSON = new JSONArray(Utils.loadJsonFromAssets(ListActivity.this, "persons.json"));
            for(int i = 0; i < personsJSON.length(); i++) {
                JSONObject person = personsJSON.getJSONObject(i);
                String firstName = person.getString("firstName");
                String city = person.getJSONObject("address").getString("city");
                persons.add(new Person(firstName, city));
            }
            Log.d("my_log", "persons: " + persons.size());
        } catch(JSONException error) {
            Toast.makeText(this, "Błąd: " + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}