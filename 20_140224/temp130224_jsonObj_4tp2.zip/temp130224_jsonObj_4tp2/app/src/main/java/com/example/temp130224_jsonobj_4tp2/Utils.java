package com.example.temp130224_jsonobj_4tp2;

import android.app.Activity;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;

public class Utils {
    public static String loadJsonFromAssets(Activity activity, String fileName) {
        String json = null;
        try {
            InputStream inputStream = activity.getAssets().open(fileName);
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();

            json = new String(buffer, "UTF-8");
        } catch(IOException error) {
            Toast.makeText(activity.getApplicationContext(), "Error: " + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            return "";
        }

        return json;
    }
}
