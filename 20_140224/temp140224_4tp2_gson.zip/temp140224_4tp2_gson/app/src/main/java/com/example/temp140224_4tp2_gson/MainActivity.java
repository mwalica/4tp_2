package com.example.temp140224_4tp2_gson;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.temp140224_4tp2_gson.model.Post;
import com.google.gson.Gson;

import org.json.JSONException;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);
        Gson gson = new Gson();

//        try {
//            Post post = gson.fromJson(loadJsonFromAssets(), Post.class);
//            String str = post.getTitle() + "\n"+ post.getContent();
//            tvResult.setText(str);
//        } catch(Exception e) {
//            Toast.makeText(this, "błąd: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//        }

        try {
           Post[] posts = gson.fromJson(loadJsonFromAssets(), Post[].class);
           tvResult.setText(posts.length + "");
        } catch(Exception e) {
            Toast.makeText(this, "błąd: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public String loadJsonFromAssets() {
        String json = null;
        try {
            InputStream inputStream = getAssets().open("posts.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();

            json = new String(buffer, "UTF-8");
        } catch(IOException error) {
            Toast.makeText(MainActivity.this, "Error: " + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            return "";
        }

        return json;
    }
}